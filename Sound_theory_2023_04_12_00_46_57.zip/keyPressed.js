//
 function keyPressed() {

  //if (mouseX <= x+20 && mouseX >= x-20)
  //r = random (150)
  //g = random (50)
  //b = random (250)
  
 //clear(); 
 background(random (255),random (150),random (150))
 
if (value === 0) {
 value = random(50); 
 } else {
   value = 0;
 }

}